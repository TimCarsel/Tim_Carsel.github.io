library(testthat)
library(pairwiseComparisons)

test_check("pairwiseComparisons")
