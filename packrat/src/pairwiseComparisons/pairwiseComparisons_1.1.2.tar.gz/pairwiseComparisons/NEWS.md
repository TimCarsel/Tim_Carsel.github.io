# pairwiseComparisons 1.1.2

  - Hot fix release to address failing tests on the old release of `R` (`3.6`).

# pairwiseComparisons 1.1.1

  - For repeated measures datasets with `NA`s present, the Bayes Factor values
    were incorrect. This is fixed.

  - Internal refactoring to improve data wrangling using `ipmisc`.

# pairwiseComparisons 1.0.0

  - Removes dependence on `jmv` and instead relies on `dunn.test` and
    `PMCMRplus`. This significantly reduces number of dependencies.
  
  - The non-parametric Dwass test has been changed to Dunn test.

# pairwiseComparisons 0.3.1

  - Adapts to breaking changes in upcoming release of `broom 0.7.0`.
  
  - Thanks to Sarah, the package has a hexsticker. :)

# pairwiseComparisons 0.3.0

  - Due to changes made to downstream dependencies, the minimum R version
    expected is bumped to `3.6.0`.

  - Adds support for the Bayes Factor tests.

  - Exports the internal helper function `pairwise_caption`.

# pairwiseComparisons 0.2.5

  - Maintenance release to import functions from `ipmisc`.

# pairwiseComparisons 0.2.0

  - `pairwise_comparisons_caption` is removed since it was helpful only for
    `ggstatsplot`'s internal graphics display and wasn't of much utility outside
    of that context.

# pairwiseComparisons 0.1.3

  - Instead of cluttering the terminal with messages, `pairwise_comparisons`
    function now instead adds two columns (`test.details` and
    `p.value.adjustment`) to all outputs specifying which test was carried out
    and which adjustment method is being used for *p*-value correction.
  - Gets rid of `groupedstats` and `crayon` from dependencies.

# pairwiseComparisons 0.1.2

  - With `jmv 1.0.8`, the results from the Dwass-Steel-Crichtlow-Fligner test
    will be slightly different.

# pairwiseComparisons 0.1.1

  - The `p.value.label` in the output dataframe has been renamed to `label` to
    consider the possibility that Bayes Factor tests might also be supported in
    future.
    
  - The label now specified whether the *p*-value was adjusted or not for
    multiple comparisons.

# pairwiseComparisons 0.1.0

  - First release of the package.
