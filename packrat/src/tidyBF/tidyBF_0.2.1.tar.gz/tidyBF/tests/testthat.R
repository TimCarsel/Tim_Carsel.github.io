library(testthat)
library(tidyBF)

test_check("tidyBF")
