library("testthat")
library("metaBMA")
library("rstan")

stopifnot(require("rstan"))

test_check("metaBMA")
