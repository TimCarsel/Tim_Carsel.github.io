library(testthat)
library(correlation)

test_check("correlation")
