model.matrix.mcp <-
function(object,...)
{
  object$contrasts
}
