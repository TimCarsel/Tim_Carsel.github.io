rmanogsub<-function(isub,x,est=onestep,...){
tsub <- est(x[isub],...)
tsub
}