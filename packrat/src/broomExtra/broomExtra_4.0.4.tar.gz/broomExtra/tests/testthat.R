library(testthat)
library(broomExtra)

test_check("broomExtra")
