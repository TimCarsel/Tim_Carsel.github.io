#include <R.h>
#include <Rdefines.h>

SEXP between_num_lr( SEXP x, SEXP from, SEXP to);
SEXP between_num_l( SEXP x, SEXP from, SEXP to);
SEXP between_num_r( SEXP x, SEXP from, SEXP to);
SEXP between_num_( SEXP x, SEXP from, SEXP to);

SEXP between_num_lrm( SEXP x, SEXP from, SEXP to);
SEXP between_num_lm( SEXP x, SEXP from, SEXP to);
SEXP between_num_rm( SEXP x, SEXP from, SEXP to);
SEXP between_num_m( SEXP x, SEXP from, SEXP to);


