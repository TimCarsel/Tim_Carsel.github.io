#' @title [Defunct!] Pairwise sign tests
#' @description Defunct. Performs pairwise sign tests.
#' @param ... Anything.
#' @return NULL
#' @export
pairwiseSignTest <- function(...) {
  .Defunct(
    msg = "'pairwiseSignTest' is defunct.\nUse PMCMR or PMCMRplus packages.")
}