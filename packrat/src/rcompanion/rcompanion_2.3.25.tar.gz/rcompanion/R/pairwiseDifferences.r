#' @title [Defunct!] Pairwise differences for unreplicated CBD
#' @description Defunct. Calculates the differences in the response variable
#'              for each pair of levels of a grouping variable 
#'              in an unreplicated complete block design.
#' @param ... Anything.
#' @return NULL
#' @export
pairwiseDifferences <- function(...) {
  .Defunct(
    msg = "'pairwiseDifferences' is defunct.")
}