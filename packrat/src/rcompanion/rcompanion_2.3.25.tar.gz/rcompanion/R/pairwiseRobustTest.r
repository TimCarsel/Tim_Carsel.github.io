#' @title [Defunct!] Pairwise two-sample robust tests
#' @description Defunct. Performs pairwise two-sample robust tests across groups.
#' @param ... Anything.
#' @return NULL
#' @export
pairwiseRobustTest <- function(...) {
  .Defunct(
    msg = "'pairwiseRobustTest' is defunct.")
}