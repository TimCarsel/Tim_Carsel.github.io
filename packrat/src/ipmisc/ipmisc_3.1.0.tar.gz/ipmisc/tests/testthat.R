library(testthat)
library(ipmisc)

test_check("ipmisc")
