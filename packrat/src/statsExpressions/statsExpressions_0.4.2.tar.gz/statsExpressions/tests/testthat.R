library(testthat)
library(statsExpressions)

test_check("statsExpressions")
