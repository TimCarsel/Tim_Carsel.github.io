test_length(clr_saturate)
test_length(clr_desaturate)

test_color_class(clr_saturate)
test_color_class(clr_desaturate)

test_wrong_input(clr_saturate)
test_wrong_input(clr_desaturate)

test_severity(clr_saturate)
test_severity(clr_desaturate)

test_severity_range(clr_saturate)
test_severity_range(clr_desaturate)

test_severity_0(clr_saturate, tol = 1)
test_severity_0(clr_desaturate, tol = 1)
