# prismatic 0.2.0

* Added `clr_alpha()` function to specify transparency. (#9)
* Added `labels` argument to `plot.colors()` to show hexcode in plot. (#8)
* `clr_rotate()`'s argument `degrees` now default to 0.
* `clr_mix()`'s argument `ratio` now correctly takes varied lengths as the argument.
* added `check_color_blindness()` to allow quick visual color deficiency examination. (#11)

# prismatic 0.1.0

* Release on CRAN
