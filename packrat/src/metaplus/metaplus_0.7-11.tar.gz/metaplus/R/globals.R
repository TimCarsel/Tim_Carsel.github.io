utils::globalVariables(c("newstart.meta","profilemix.fit0","p","profilenorm.start","profilenorm.fit0","profilet.fit0","isreg","grad","mymle.options"))
