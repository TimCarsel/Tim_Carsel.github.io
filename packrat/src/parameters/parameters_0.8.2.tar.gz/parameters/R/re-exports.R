#' @importFrom insight format_number
#' @export
insight::format_number

#' @importFrom insight format_p
#' @export
insight::format_p

#' @importFrom insight format_rope
#' @export
insight::format_rope

#' @importFrom insight format_bf
#' @export
insight::format_bf

#' @importFrom insight format_pd
#' @export
insight::format_pd
