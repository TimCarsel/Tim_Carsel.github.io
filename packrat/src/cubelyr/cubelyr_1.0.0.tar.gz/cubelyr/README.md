# cubelyr

<!-- badges: start -->
<!-- badges: end -->

cubelyr pulls the experimental `tbl_cube()` out of dplyr, so you can continue to use it if you want.

## Installation

You can install the released version of cubelyr from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("cubelyr")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(cubelyr)
## basic example code
```

