SEXP // keep in sync with ./init.c
    Rmpfr_precSym,
    Rmpfr_signSym,
    Rmpfr_expSym,
    Rmpfr_d_Sym,
    Rmpfr_Data_Sym,
    Rmpfr_Dim_Sym,
    Rmpfr_Dimnames_Sym
    ;

