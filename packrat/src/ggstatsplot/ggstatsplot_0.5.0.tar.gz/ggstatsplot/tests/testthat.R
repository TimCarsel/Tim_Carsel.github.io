library(testthat)
library(ggstatsplot)

test_check("ggstatsplot")
